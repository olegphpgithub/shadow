#include "../../gettext-tools/lib/strerror.c"
