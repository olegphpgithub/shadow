#include "../../gettext-tools/lib/alloca.c"
